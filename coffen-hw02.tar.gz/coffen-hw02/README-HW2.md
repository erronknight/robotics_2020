Sarah Coffen
https://github.com/erronknight/robotics_2020 (coffen-hw02 folder)
https://www.youtube.com/watch?v=PQPzYwvbDms&feature=youtu.be 
DeltaV = 503 m/s
I used the quickstart tutorial as a base and the following code sources for aide:
https://www.reddit.com/r/Kos/comments/3ijayc/recommended_ascent_curves/ (user space_is_hard)
https://www.reddit.com/r/Kos/comments/495a35/automated_nearperfect_circular_orbit_manouver/ (Giacomo Rizzi @gufoe on Github)