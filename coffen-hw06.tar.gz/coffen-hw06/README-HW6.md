Sarah Coffen
https://www.youtube.com/watch?v=qzZXO0RNIoM&feature=youtu.be

Based Bresenham functions off of here: https://www.geeksforgeeks.org/bresenhams-line-generation-algorithm/
Used Log Odd measures from Penn state videos: https://www.youtube.com/watch?v=8ioYbLOICq8&list=PL_onPhFCkVQhuPiUxUW2lFHB39QsavEEA