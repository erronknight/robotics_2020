Sarah Coffen
https://github.com/erronknight/robotics_2020
https://www.youtube.com/watch?v=o71B7KUL38g&feature=youtu.be
The targeting ended up being very similar to the in class demo. Thanks!